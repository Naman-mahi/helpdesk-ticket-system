  <?php 
 if(isset($_POST['change_password'])){
 $currentPassword=$_POST['currentPassword']; 
  $password=$_POST['password'];  
 $passwordConfirm=$_POST['passwordConfirm']; 
$sql="SELECT password from users where email='$email'";
$res = mysqli_query($dbc,$sql);
      $res=mysqli_query($dbc,$sql);
        $row = mysqli_fetch_assoc($res);
       if(password_verify($currentPassword,$row['password'])){
if($passwordConfirm ==''){
            $error[] = 'Please confirm the password.';
        }
        if($password != $passwordConfirm){
            $error[] = 'Passwords do not match.';
        }
          if(strlen($password)<5){ // min 
            $error[] = 'The password is 6 characters long.';
        }
        
         if(strlen($password)>20){ // Max 
            $error[] = 'Password: Max length 20 Characters Not allowed';
        }
        if(!isset($error))
{
      $options = array("cost"=>4);
    $password = password_hash($password,PASSWORD_BCRYPT,$options);

     $result = mysqli_query($dbc,"UPDATE users SET password='$password' WHERE email='$email'");
           if($result)
           {
       header("location:account.php?password_updated=1");
           }
           else 
           {
            $error[]='Something went wrong';
           }
}

        } 
        else 
        {
            $error[]='Current password does not match.'; 
        }   
    }
        if(isset($error)){ 
          foreach($error as $error){ 
            echo '<p class="errmsg">'.$error.'</p>'; 
          }
          }
                  ?> 